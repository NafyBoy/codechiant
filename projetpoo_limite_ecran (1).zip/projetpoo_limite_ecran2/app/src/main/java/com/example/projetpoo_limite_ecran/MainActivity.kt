package com.example.projetpoo_limite_ecran

import android.os.Build.VERSION_CODES.R
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

private var Any.activity_main: Any
    get() {
        TODO("Not yet implemented")
    }
    set(value) {}
private val Any.layout: Any
    get() {
        TODO("Not yet implemented")
    }

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    private fun setContentView(activityMain: Any) {
        TODO("Not yet implemented")
    }
}
