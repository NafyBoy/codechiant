package com.example.projetpoo_limite_ecran

import android.graphics.Canvas
import android.graphics.Paint

class Paroi(val x: Float, val haut: Float, val bas: Float, val couleur: LimiteEcran.Couleur) {
    fun dessiner(canvas: Canvas, paint: Paint) {
        paint.color = couleur.valeur
        canvas.drawLine(x, haut, x, bas, paint)
    }
}