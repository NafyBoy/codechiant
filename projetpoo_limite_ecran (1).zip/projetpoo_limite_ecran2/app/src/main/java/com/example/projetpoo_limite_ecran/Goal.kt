package com.example.projetpoo_limite_ecran

import android.graphics.Canvas
import android.graphics.Paint

class Goal(val gauche: Float, val droite: Float, val y: Float, val couleur: LimiteEcran.Couleur) {
    fun dessiner(canvas: Canvas, paint: Paint) {
        paint.color = couleur.valeur
        canvas.drawLine(gauche, y, droite, y, paint)
    }
}