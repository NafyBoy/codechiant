package com.example.projetpoo_limite_ecran

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class DrawingView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {
    private lateinit var limiteEcran: LimiteEcran
    private val paint = Paint()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        limiteEcran = LimiteEcran(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (paroi in limiteEcran.parois) {
            paroi.dessiner(canvas, paint)
        }
        for (goal in limiteEcran.goals) {
            goal.dessiner(canvas, paint)
        }
    }
}