package com.example.projetpoo_limite_ecran

class LimiteEcran(private val largeur: Int, private val hauteur: Int) {
    val gauche = 0f
    val droite = largeur.toFloat()
    val haut = 0f
    val bas = hauteur.toFloat()

    val parois = mutableListOf<Paroi>()
    val goals = mutableListOf<Goal>()

    init {
        parois.add(Paroi(gauche, haut, bas, Couleur.JAUNE))
        parois.add(Paroi(droite, haut, bas, Couleur.JAUNE))
        goals.add(Goal(gauche, droite, haut, Couleur.VERT))
        goals.add(Goal(gauche, droite, bas, Couleur.VERT))
    }

    interface Couleur {
        var valeur: Int

        object VERT : LimiteEcran.Couleur {
            override var valeur: Int
                get() = TODO("Not yet implemented")
                set(value) {}
        }
        object JAUNE : LimiteEcran.Couleur {
            override var valeur: Int
                get() = TODO("Not yet implemented")
                set(value) {}
        }
    }
}




